from flask import Flask,render_template
app=Flask(__name__)
@app.route('/',methods=['Get'])
def index():
    return render_template('index.html')

@app.route('/',methods=['Get'])
def inner_page():
    return render_template('inner_page.html')
@app.route('/attendence',methods=['Get'])
def portfolio_details ():
    return render_template('portfolio_details.html')

if __name__=='__main__':
    app.run(debug=True)
   


